<?php

error_reporting(0);
$servername = "localhost"; // Do not change this
$dbname = "zero_db"; // Your db Name goes here
$dbuser = "zero_user"; //Your db Username goes here.
$dbpass = "AnonymousUser1"; //Database Password goes here

//Settings
$One_Time_Access = "on"; //To turn off, simply change to "off"

// admin panel password
$admin_password = "ad1234"; // make sure to change this one

// Live Panel Purchase / Authorisation code
$Purchase_Key = "@YourUsername"; // This is needed or else panel will not work. Purchase only from - the coder

?>